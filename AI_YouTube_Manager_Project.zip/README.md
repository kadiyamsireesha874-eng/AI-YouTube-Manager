# AI YouTube Manager

A Streamlit dashboard that uploads a video to Gemini and drafts YouTube metadata:
titles, descriptions, tags, hashtags, keywords, thumbnail text and a summary.

## 1. Get a Gemini API key

1. Open Google AI Studio: https://aistudio.google.com/
2. Sign in and create an API key.
3. Keep the key private. Do not paste it into `app.py` or commit it to GitHub.

## 2. Run locally

Python 3.10+ is recommended.

```bash
pip install -r requirements.txt
streamlit run app.py
```

Paste your Gemini API key into the password field in the sidebar.

## 3. Deploy with GitHub + Streamlit Community Cloud

1. Create a new GitHub repository, for example `ai-youtube-manager`.
2. Upload `app.py`, `requirements.txt`, `README.md`, and `.gitignore`.
3. Open https://share.streamlit.io/ and sign in with GitHub.
4. Choose **Create app**, select your repository and `app.py`, then deploy.
5. In the deployed app settings, open **Secrets** and add:

```toml
GEMINI_API_KEY = "paste-your-key-here"
```

6. Save and restart/redeploy the app if needed.

## Security

- Never commit API keys, OAuth client secrets, access tokens or `.streamlit/secrets.toml`.
- If a key is exposed, revoke it in Google AI Studio and create a new one.
- The app uses the key server-side. It does not publish videos or connect to your YouTube account.
- Uploaded videos are sent to Gemini for analysis. Review Google's API data-use terms before uploading private or sensitive footage.

## Version 1 limitations

- Metadata suggestions are AI-generated, not guaranteed trending keywords or guaranteed views.
- No direct YouTube publishing or channel analytics yet.
- You must review the title, description and tags and paste them into YouTube Studio yourself.
- Gemini model availability depends on your API key, region and account. If the default model is unavailable, try the alternate model in the sidebar.
