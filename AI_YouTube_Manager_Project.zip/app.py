import json
import os
import re
import tempfile
import time
from typing import Any

import streamlit as st
from google import genai
from google.genai import types

st.set_page_config(
    page_title="AI YouTube Manager",
    page_icon="▶️",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
.main {max-width: 1150px; padding-top: 1.5rem;}
.hero {padding: 1.4rem 1.6rem; border-radius: 18px;
       background: linear-gradient(120deg,#151b35,#29205a); color:white;
       margin-bottom: 1rem;}
.hero h1 {margin:0; font-size:2rem;}
.hero p {margin:.4rem 0 0 0; opacity:.85;}
div[data-testid="stMetric"] {background:rgba(120,120,150,.10);
 padding:12px; border-radius:12px;}
</style>
""", unsafe_allow_html=True)

st.markdown("""
<div class="hero">
  <h1>▶️ AI YouTube Manager</h1>
  <p>Upload a video • Let Gemini understand it • Prepare YouTube SEO metadata</p>
</div>
""", unsafe_allow_html=True)

def get_api_key() -> str:
    try:
        key = st.secrets.get("GEMINI_API_KEY", "")
    except Exception:
        key = ""
    return key or st.session_state.get("manual_api_key", "")

def extract_json(text: str) -> dict[str, Any]:
    cleaned = text.strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
    cleaned = re.sub(r"\s*```$", "", cleaned)
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", cleaned, re.S)
        if match:
            return json.loads(match.group(0))
        raise ValueError("Gemini returned a response that was not valid JSON.")

def render_copy_field(label: str, value: str, key: str, height: int = 110):
    st.markdown(f"**{label}**")
    st.text_area(label, value=value, height=height, key=f"view_{key}",
                 label_visibility="collapsed")
    st.download_button(
        f"Download {label}",
        data=value,
        file_name=f"{key}.txt",
        mime="text/plain",
        key=f"download_{key}",
        use_container_width=False,
    )

with st.sidebar:
    st.header("⚙️ Settings")
    st.caption("Gemini API connection")
    api_key_input = st.text_input(
        "Gemini API Key",
        type="password",
        help="Paste your key from Google AI Studio. It is used for this session only.",
    )
    if api_key_input:
        st.session_state["manual_api_key"] = api_key_input
    st.caption("For deployment, add GEMINI_API_KEY in Streamlit Secrets.")
    model = st.selectbox(
        "Gemini model",
        ["gemini-3.8-flash", "gemini-2.5-flash"],
        index=0,
        help="If the selected model is unavailable to your API key, try the other option."
    )
    language = st.selectbox("Output language", ["Telugu", "English", "Telugu + English"], index=2)
    audience = st.text_input("Target audience", "Telugu-speaking YouTube viewers")
    channel_niche = st.text_input("Channel niche", "Comedy, funny AI videos and reels")
    st.divider()
    st.caption("Version 1.0 • Metadata assistant")

api_key = get_api_key()

left, right = st.columns([1.25, 0.75], gap="large")
with left:
    st.subheader("1. Upload your video")
    uploaded = st.file_uploader(
        "Choose a video file",
        type=["mp4", "mov", "mpeg", "mpg", "avi", "wmv", "webm", "3gpp"],
        help="For best results, start with a short MP4 video. Upload limits depend on your hosting plan."
    )
    extra_context = st.text_area(
        "Optional context",
        placeholder="Example: Two village monkeys play near a pond. Make the title funny.",
        height=90
    )
with right:
    st.subheader("2. What Gemini will prepare")
    st.markdown("""
    - Search-friendly title ideas
    - Video description
    - Relevant tags and hashtags
    - Main keywords
    - Thumbnail text ideas
    - Category suggestion
    - Short video summary
    """)
    st.info("Tags are relevant suggestions, not guaranteed trending tags or a promise of views.")

st.divider()

def analyze_video(file_bytes: bytes, file_name: str, mime_type: str, prompt: str):
    client = genai.Client(api_key=api_key)
    suffix = os.path.splitext(file_name)[1] or ".mp4"
    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            tmp.write(file_bytes)
            tmp_path = tmp.name

        status = st.status("Uploading video to Gemini…", expanded=True)
        video_file = client.files.upload(file=tmp_path)
        status.write("Waiting for Gemini to process the video…")

        deadline = time.time() + 300
        while True:
            current = client.files.get(name=video_file.name)
            state = getattr(current, "state", None)
            state_name = getattr(state, "name", str(state)).upper() if state else ""
            if state_name == "ACTIVE":
                video_file = current
                break
            if state_name == "FAILED":
                raise RuntimeError("Gemini could not process this video. Try another MP4 file.")
            if time.time() > deadline:
                raise TimeoutError("Video processing took too long. Try a shorter or smaller video.")
            time.sleep(5)

        status.write("Analyzing scenes, actions and audio context…")
        schema_prompt = f"""
You are an experienced YouTube metadata assistant. Analyze the supplied video itself.
Create useful, accurate metadata. Do not invent events, dialogue, people, locations or claims
that are not supported by the video or optional context.

Channel niche: {channel_niche}
Target audience: {audience}
Output language: {language}
Additional user context: {prompt if prompt else "None"}

Return ONLY valid JSON with exactly these keys:
{{
 "video_summary": "2-4 sentence summary",
 "title_options": ["title 1", "title 2", "title 3"],
 "recommended_title": "best title",
 "description": "ready-to-paste YouTube description; include a natural call to action",
 "tags": ["tag 1", "tag 2"],
 "hashtags": ["#hashtag1", "#hashtag2"],
 "keywords": ["keyword 1", "keyword 2"],
 "thumbnail_text_options": ["short text 1", "short text 2", "short text 3"],
 "category_suggestion": "best-fit YouTube category",
 "audience_hook": "one short opening hook",
 "content_notes": ["any uncertainty or helpful note"]
}}

Keep titles clear and truthful. Avoid keyword stuffing, misleading clickbait and claims of guaranteed virality.
Tags must be relevant to the actual content. Do not claim they are live trending terms.
"""
        response = client.models.generate_content(
            model=model,
            contents=[video_file, schema_prompt],
            config=types.GenerateContentConfig(
                response_mime_type="application/json",
                temperature=0.5,
            ),
        )
        status.update(label="Analysis complete", state="complete", expanded=False)
        return extract_json(response.text or "")
    finally:
        if tmp_path and os.path.exists(tmp_path):
            os.remove(tmp_path)

if st.button("✨ Analyze video with Gemini", type="primary", use_container_width=True,
             disabled=(uploaded is None)):
    if not api_key:
        st.error("Please enter your Gemini API key in the sidebar first.")
    elif uploaded is None:
        st.warning("Upload a video first.")
    else:
        try:
            with st.spinner("Gemini is preparing your YouTube details…"):
                result = analyze_video(
                    uploaded.getvalue(),
                    uploaded.name,
                    uploaded.type or "video/mp4",
                    extra_context,
                )
            st.session_state["analysis_result"] = result
            st.success("Your video metadata is ready!")
        except Exception as exc:
            st.error(f"Could not analyze the video: {exc}")
            st.caption("Check your API key, model access, internet connection and video format.")

result = st.session_state.get("analysis_result")
if result:
    st.divider()
    st.header("3. Your YouTube SEO results")
    st.markdown("**Video summary**")
    st.write(result.get("video_summary", ""))

    st.subheader("Recommended title")
    render_copy_field("Recommended title", result.get("recommended_title", ""), "recommended_title", 70)

    titles = result.get("title_options", [])
    if titles:
        with st.expander("More title ideas"):
            for i, title in enumerate(titles, 1):
                st.write(f"{i}. {title}")

    render_copy_field("Description", result.get("description", ""), "description", 220)

    tags = result.get("tags", [])
    render_copy_field("Tags (comma separated)", ", ".join(tags), "tags", 100)

    hashtags = result.get("hashtags", [])
    render_copy_field("Hashtags", " ".join(hashtags), "hashtags", 70)

    keywords = result.get("keywords", [])
    render_copy_field("Keywords", ", ".join(keywords), "keywords", 90)

    st.subheader("Thumbnail text ideas")
    for idea in result.get("thumbnail_text_options", []):
        st.write(f"• {idea}")

    c1, c2 = st.columns(2)
    c1.metric("Suggested category", result.get("category_suggestion", "Not specified"))
    c2.metric("Opening hook", result.get("audience_hook", "Not specified"))

    notes = result.get("content_notes", [])
    if notes:
        with st.expander("Notes and checks"):
            for note in notes:
                st.write(f"• {note}")

    export_data = json.dumps(result, ensure_ascii=False, indent=2)
    st.download_button(
        "⬇️ Download all results (JSON)",
        data=export_data,
        file_name="youtube_video_metadata.json",
        mime="application/json",
        type="primary",
    )
    st.caption("Review all details before publishing. YouTube Studio remains the place to paste and save metadata.")

st.divider()
st.caption("AI YouTube Manager is an independent helper app, not an official YouTube or Google product.")
